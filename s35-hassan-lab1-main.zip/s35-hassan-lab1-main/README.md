#s35-hassan-lab1

# In this lab sheet I created a remote repo.
# Connected it to my local repo.
# Pushed changes remotely.

# Also I have forked an existing repo.
# Cloned a repo locally.
# Have done some changes to readme file using "vim".
"vim README.md"
# Pushed the changes to forked repo.
# Generated a pull request to original forked repo.

# Have done local configuration.

# In last created an empty repo.
# Populate it the repo with some files.
# Commited changes locally.

